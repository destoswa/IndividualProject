# Dataset
You can find our dataset with partial [single-view PCDs](https://drive.google.com/file/d/1Z-Te9Vw_PhQDCIc_zxyemwiBjI-BeBLK/view?usp=sharing) generated from benchmark dataset ModelNet40. Plese download the dataset, creat a directory named *"single_view_modelnet"* and put it under *"data"* directory.
