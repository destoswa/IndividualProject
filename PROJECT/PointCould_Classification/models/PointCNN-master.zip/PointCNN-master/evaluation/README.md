# Evaluation

Before evaluate s3dis or semantic3d,please run this command firstly:

```
python3 s3dis_merge.py
or
python3 semantic3d_merge.py
```
